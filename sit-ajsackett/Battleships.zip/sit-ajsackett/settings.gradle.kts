include(":app")
include(":lib")
include(":testlib")
include(":logic")
rootProject.name = "Battleships"